export const LANGS=['zh-Hans','zh-Hant','en'];
export const TEXT={
 title:['怪物岛：潮汐回响','怪物島：潮汐迴響','Monster Island: Tidal Echoes'],
 edition:['家庭测试版 2.0','家庭測試版 2.0','FAMILY BETA 2.0'],
 intro:['两名探险家。两种力量。一座不再沉默的岛。','兩名探險家。兩種力量。一座不再沉默的島。','Two explorers. Two powers. An island that fights back.'],
 alex:['电力发明家','電力發明家','Electric inventor'],victory:['重力魔法师','重力魔法師','Gravity mage'],
 alexDesc:['按住电弧连续攻击；超载电磁炮造成高伤害。','按住電弧連續攻擊；超載電磁炮造成高傷害。','Hold Arc to attack. Overcharge delivers a powerful burst.'],
 victoryDesc:['第一次按抓起地上的石头，第二次按投掷；重力场打断蓄力。','第一次按抓起地上的石頭，第二次按投擲；重力場打斷蓄力。','Tap once to lift a nearby rock; tap again to throw. Gravity interrupts attacks.'],
 solo:['独自出发','獨自出發','Set sail solo'],host:['创建双人房间','建立雙人房間','Create co-op room'],join:['加入房间','加入房間','Join room'],
 room:['房间代码','房間代碼','Room code'],roomHint:['两台设备打开同一个本地服务器地址，再输入房间代码。','兩台裝置開啟同一個本機伺服器網址，再輸入房間代碼。','Open the same local server on both devices, then enter the room code.'],
 lanOnly:['双人模式需要本地服务器；此公开网页可以直接玩单人。','雙人模式需要本機伺服器；此公開網頁可直接玩單人。','Co-op needs the local server. This public page supports solo play.'],
 waiting:['等待另一名探险家加入。','等待另一名探險家加入。','Waiting for your fellow explorer.'],connected:['两人已就位：主机点击开始。','兩人已就位：主機點擊開始。','Both explorers are here. The host can launch.'],launch:['一起出发','一起出發','Launch together'],cancel:['返回','返回','Back'],
 pause:['暂停','暫停','Pause'],resume:['继续','繼續','Resume'],retry:['重新挑战','重新挑戰','Try again'],home:['作品主页','作品主頁','Project hub'],menu:['选择角色','選擇角色','Choose explorer'],
 controls:['左侧移动 · 右侧技能 · 双指可同时操作','左側移動 · 右側技能 · 雙指可同時操作','Move on the left · Skills on the right · Use both thumbs'],
 keyboard:['WASD 移动 · E 攻击 · Q 特技 · 空格闪避 · R 重压','WASD 移動 · E 攻擊 · Q 特技 · 空格閃避 · R 重壓','WASD move · E attack · Q special · Space dodge · R anchor'],
 attack:['电弧','電弧','Arc'],lift:['抓起石头','抓起石頭','Lift rock'],throw:['投掷','投擲','Throw'],lifting:['悬浮中','懸浮中','Lifting'],special:['超载','超載','Overcharge'],gravity:['重力场','重力場','Gravity'],dash:['闪避','閃避','Dodge'],anchor:['重压','重壓','Anchor'],locked:['首胜解锁','首勝解鎖','Win to unlock'],
 hp:['生命','生命','Health'],coins:['水晶','水晶','Crystals'],round:['挑战','挑戰','Challenge'],guardian:['三头潮汐兽','三頭潮汐獸','The Tidekeeper'],
 beach:['沿金色路标前进。靠近洞口时，先观察守卫。','沿金色路標前進。靠近洞口時，先觀察守衛。','Follow the golden trail. Watch the guardian before you enter.'],
 watch:['它正盯着你。继续靠近就会封闭战斗区域。','牠正盯著你。繼續靠近就會封閉戰鬥區域。','It is watching. Step closer to seal the arena and begin.'],
 fight:['边跑边反击！红色标记出现时离开危险区域。','邊跑邊反擊！紅色標記出現時離開危險區域。','Keep moving and fight back. Escape the red warning areas.'],
 introCaption:['五头小蛇误闯领地……守卫张开了嘴！','五頭小蛇誤闖領地……守衛張開了嘴！','A five-headed snake strays too close… the guardian snaps!'],
 skip:['跳过演出','跳過演出','Skip scene'],loot:['守卫倒下了！走到洞口宝箱旁，领取水晶并进入升级机。','守衛倒下了！走到洞口寶箱旁，領取水晶並進入升級機。','Guardian defeated! Walk to the chest by the cave to open the upgrade machine.'],
 stomp:['落石重击：跑出红圈！','落石重擊：跑出紅圈！','Crushing strike: leave the red circles!'],breath:['远程喷射：横向移动，躲过弹幕！','遠程噴射：橫向移動，躲過彈幕！','Tidal volley: move sideways around the projectiles!'],charge:['冲锋：离开红色通道！','衝鋒：離開紅色通道！','Charge: get out of the red lane!'],roar:['震荡吼叫：及时闪避，或用重压减伤！','震盪吼叫：及時閃避，或用重壓減傷！','Shock roar: time a dodge, or Anchor to reduce damage!'],
 enrage:['守卫狂暴了，蓄力变快！','守衛狂暴了，蓄力變快！','Enraged! The guardian attacks faster!'],
 noRock:['靠近带紫色光圈的石头，再按抓取。','靠近帶紫色光圈的石頭，再按抓取。','Move near a purple-ringed rock, then tap Lift.'],approach:['先进入守卫领地。','先進入守衛領地。','Enter the guardian’s territory first.'],
 shop:['水晶升级机','水晶升級機','Crystal upgrade machine'],shopText:['首胜解锁重压：短时间减伤、抵抗击退，但移动变慢。升级完成后挑战更强的守卫。','首勝解鎖重壓：短時間減傷、抵抗擊退，但移動變慢。升級完成後挑戰更強的守衛。','First victory unlocks Anchor: take less damage and resist knockback, but move slowly. Upgrade before a stronger rematch.'],
 power:['攻击强化','攻擊強化','Power'],health:['生命强化','生命強化','Vitality'],cooldown:['冷却强化','冷卻強化','Recovery'],
 powerDesc:['每级提高 15% 攻击伤害','每級提高 15% 攻擊傷害','+15% attack damage per level'],healthDesc:['每级增加 20 点生命上限','每級增加 20 點生命上限','+20 maximum health per level'],cooldownDesc:['每级缩短 10% 冷却','每級縮短 10% 冷卻','10% shorter cooldowns per level'],
 buy:['购买','購買','Buy'],max:['已满级','已滿級','Max level'],level:['等级','等級','Level'],insufficient:['水晶不足。','水晶不足。','Not enough crystals.'],rematch:['挑战强化守卫','挑戰強化守衛','Stronger rematch'],finish:['完成远征','完成遠征','Finish expedition'],
 won:['第一段远征完成！','第一段遠征完成！','Your first expedition is complete!'],wonText:['水晶与升级已保存。雨林、火山、城堡和最终 100 水晶宝箱是后续内容。','水晶與升級已儲存。雨林、火山、城堡和最終 100 水晶寶箱是後續內容。','Solo upgrades and crystals are saved. The rainforest, volcano, castle and final 100-crystal treasure are future chapters.'],
 dead:['回船边，再试一次。','回船邊，再試一次。','Back to the boat. Try again.'],deadText:['看红色预警、用闪避避开攻击。Victory 可以用重力场打断蓄力。','看紅色預警、用閃避避開攻擊。Victory 可以用重力場打斷蓄力。','Watch the warnings and dodge. Victory can interrupt a wind-up with Gravity.'],
 breathe:['喘口气，冒险已暂停。','喘口氣，冒險已暫停。','Take a breath. The adventure is paused.'],
 netPaused:['队友掉线或切到后台，全队已暂停。两人重新连接后可继续。','隊友離線或切到背景，全隊已暫停。兩人重新連線後可繼續。','A teammate disconnected or switched away. The team is paused; resume when both return.'],
 music:['音乐','音樂','Music'],sound:['音效','音效','Sound effects'],motion:['减少动态效果','減少動態效果','Reduced motion'],
 settings:['声音与显示','聲音與顯示','Sound & display'],reset:['清除本机单人存档','清除本機單人存檔','Reset local solo save'],resetConfirm:['确定清除本机的水晶与升级吗？','確定清除本機的水晶與升級嗎？','Clear crystals and upgrades saved on this device?'],
 saved:['仅在这台设备保存单人进度；联机是独立的一局。','僅在這台裝置儲存單人進度；連線是獨立的一局。','Solo progress stays on this device. Co-op runs are separate.'],
 error:['加载失败，请刷新页面。','載入失敗，請重新整理頁面。','Loading failed. Reload the page.'],networkError:['连接失败，请确认房间代码和本地服务器。','連線失敗，請確認房間代碼和本機伺服器。','Connection failed. Check the room code and local server.'],
 review:['记录试玩反馈','記錄試玩回饋','Record playtest feedback'],beta:['浏览器真机验收待完成；遇到问题请在主页记录反馈。','瀏覽器真機驗收待完成；遇到問題請在主頁記錄回饋。','Physical-device acceptance is still pending. Report issues through the hub.'],
 spectator:['你暂时倒下了，等待队友完成挑战。','你暫時倒下了，等待隊友完成挑戰。','You are down. Your teammate can still finish the fight.'],
 roomFull:['房间不存在或已满。','房間不存在或已滿。','Room missing or full.'],hostOnly:['此操作由房主执行。','此操作由房主執行。','The host controls this action.'],
 readOnly:['准备好再一起出发。','準備好再一起出發。','Ready when you are.']
};
export function validLang(v){return LANGS.includes(v)?v:'en';}
export function t(key,lang='en'){return TEXT[key]?.[LANGS.indexOf(validLang(lang))]??key;}
export function initialLang(){let saved;try{saved=localStorage.getItem('island-language');}catch{}return validLang(new URLSearchParams(location.search).get('lang')||saved||'en');}

Object.assign(TEXT,{
 edition:['家庭试玩版 2.1','家庭試玩版 2.1','FAMILY EDITION 2.1'],attack:['电磁弹','電磁彈','RAIL SHOT'],special:['超载炮','超載炮','OVERCHARGE'],anchor:['跃起压砸','躍起壓砸','LEAP SLAM'],anchorDesc:['瞄准落点，跃起砸下；中心命中造成 260 基础伤害。','瞄準落點，躍起砸下；中心命中造成 260 基礎傷害。','Aim a landing point, leap and slam. A central hit deals 260 base damage.'],showNumbers:['显示伤害与数值','顯示傷害與數值','Damage numbers & statistics'],damage:['普攻','普攻','Shot'],specialDamage:['特殊','特殊','Special'],slamDamage:['压砸','壓砸','Slam'],aimTitle:['选择你的落点','選擇你的落點','CHOOSE YOUR LANDING'],aimHelp:['拖动地面或推摇杆瞄准；亮色内圈是高伤害区。','拖動地面或推搖桿瞄準；亮色內圈是高傷害區。','Drag the ground or use the stick to aim. The bright inner circle deals full damage.'],confirmSlam:['跃起压砸 · R / Enter','躍起壓砸 · R / Enter','LEAP & SLAM · R / Enter'],cancelAim:['取消瞄准','取消瞄準','Cancel aim'],prologue:['海岸上的警告','海岸上的警告','A WARNING ON THE SHORE'],
 storyBoat:['Alex 和 Victory 带着装备，踏上未知的海岸。','Alex 和 Victory 帶著裝備，踏上未知的海岸。','Alex and Victory step ashore, prepared for the unknown.'],
 storyWalk:['山洞就在前面。可那沉重的脚步声……','山洞就在前面。可那沉重的腳步聲……','The cave lies ahead. But those heavy footsteps…'],
 storyHide:['嘘——躲到岩石后面。它在守着入口。','噓——躲到岩石後面。牠在守著入口。','Quiet. Behind the rock. Something is guarding the entrance.'],
 storySnake:['一条五头蛇，正从侧面闯进它的领地。','一條五頭蛇，正從側面闖進牠的領地。','A five-headed serpent slithers into the guardian’s territory.'],
 storyRoar:['三颗头同时抬起。警告声震动了整个海滩。','三顆頭同時抬起。警告聲震動了整個海灘。','Three heads rise. A warning roar shakes the shore.'],
 storyDefy:['五头蛇没有逃。它昂起每一颗头，发出挑衅的嘶声。','五頭蛇沒有逃。牠昂起每一顆頭，發出挑釁的嘶聲。','The serpent does not flee. All five heads rise in defiance.'],
 storyEat:['守卫猛扑、张口。五头蛇消失在巨口之中。','守衛猛撲、張口。五頭蛇消失在巨口之中。','The guardian lunges. Its jaws close around the serpent.'],
 storyReady:['他们交换了一个眼神。现在，轮到你决定如何前进。','他們交換了一個眼神。現在，輪到你決定如何前進。','The explorers exchange a glance. Now you decide how to proceed.']
});

Object.assign(TEXT,{bolt:['电磁弹','電磁彈','RAIL SHOT'],beam:['超载电磁炮','超載電磁炮','OVERCHARGE'],alexDesc:['电磁弹有真实飞行轨迹；超载炮发射更大的高伤害弹丸。','電磁彈有真實飛行軌跡；超載炮發射更大的高傷害彈丸。','Fire visible rail slugs. Overcharge launches a larger, high-damage projectile.']});
